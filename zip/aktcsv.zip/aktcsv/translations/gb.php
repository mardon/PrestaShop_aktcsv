<?php                                                                                                                                                                                     
                                                                                                                                                                                          
global $_MODULE;                                                                                                                                                                          
$_MODULE = array();                                                                                                                                                                       
$_MODULE['<{aktcsv}prestashop>aktcsv_bb473a481ef7256c4b81a8b672c6407f'] = 'Update from CSV';                                                                                              
$_MODULE['<{aktcsv}prestashop>aktcsv_66fe16dfe63c26f3996815a90e315ac3'] = 'Update price and stock from CSV file';                                                                         
$_MODULE['<{aktcsv}prestashop>aktcsv_c7ebe1bb37fed25d8071a79bfeb64ca1'] = 'Are you sure you want to uninstall?';                                                                          
$_MODULE['<{aktcsv}prestashop>aktcsv_110987541b5d1ca8dc463751758c18ce'] = 'Recquier PrestaShop 1.5';                                                                                      
$_MODULE['<{aktcsv}prestashop>aktcsv_bcb84a69b823f4a0d72e2478c1402ebc'] = 'Choose CSV file';                                                                                              
$_MODULE['<{aktcsv}prestashop>aktcsv_fe93b889a42c0db4454c4132333540b9'] = '(cat no; name; price; amount)';                                                                                
$_MODULE['<{aktcsv}prestashop>aktcsv_8f7c1718c771b98b6c6aea58a8c2b53c'] = 'Upload file';                                                                                                  
$_MODULE['<{aktcsv}prestashop>aktcsv_39bd4b9875922ad6691d12106ea5f6c0'] = 'Main module functions';                                                                                        
$_MODULE['<{aktcsv}prestashop>aktcsv_9b038b73f21b66a505b373045da0ad6f'] = 'Update DB from file:';                                                                                         
$_MODULE['<{aktcsv}prestashop>aktcsv_6e3ba82de5f484830752a5bb79dfdbe2'] = 'Separator character *.csv';                                                                                    
$_MODULE['<{aktcsv}prestashop>aktcsv_fa5f5afe81f8b5c078e699c308efc612'] = 'Choose type of 1. column';                                                                                     
$_MODULE['<{aktcsv}prestashop>aktcsv_d65f97a671fc837690e497171da6c099'] = 'Set profit? (ex. 1.20 - 20%)';                                                                                 
$_MODULE['<{aktcsv}prestashop>aktcsv_3eb41bebd9b80ca0b31fd7a4ffcf6491'] = 'Constant profit added to price';                                                                               
$_MODULE['<{aktcsv}prestashop>aktcsv_371ed88cada9b4ff3a4bdae3093cf31f'] = 'Price type';                                                                                                   
$_MODULE['<{aktcsv}prestashop>aktcsv_acc8ea10a5fde57426760a46db2aa973'] = 'Zero prices and stocks?';                                                                                      
$_MODULE['<{aktcsv}prestashop>aktcsv_09ef89ca218d8b1e106bafd962b42889'] = 'Products with attributes?';                                                                                    
$_MODULE['<{aktcsv}prestashop>aktcsv_072c43983524bb4cb8630e11533c8e57'] = 'Missing products';                                                                                             
$_MODULE['<{aktcsv}prestashop>aktcsv_c4ca54902cbad0f18f621ad9f4b532e5'] = 'Check missing product in Database';                                                                            
$_MODULE['<{aktcsv}prestashop>aktcsv_4e4a038ba23b185a2092ca08cac80ad9'] = 'Limit stock to ...';                                                                                           
$_MODULE['<{aktcsv}prestashop>aktcsv_8e025c198c628428cf6a3cfc4c6a257f'] = 'Filter1 - what to look for?';                                                                                  
$_MODULE['<{aktcsv}prestashop>aktcsv_a71903625f6d5566b3b3ada535165f45'] = 'Id_shop - which one to update';                                                                                
$_MODULE['<{aktcsv}prestashop>aktcsv_9b26571c067060634237af3361406f5a'] = 'Process updating';                                                                                             
$_MODULE['<{aktcsv}prestashop>aktcsv_3e7952a00a96e8b64bad35f9699d691b'] = 'Please wait... This can take some time.';                                                                      
$_MODULE['<{aktcsv}prestashop>aktcsv_394e48b053002822c72fe6e6c485a2fc'] = 'Addons';                                                                                                       
$_MODULE['<{aktcsv}prestashop>aktcsv_761fae7f6776e66311ae847b2c38d3ef'] = 'Missed products log file:';